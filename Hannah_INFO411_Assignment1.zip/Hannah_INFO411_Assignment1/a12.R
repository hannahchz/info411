#Appendix C:SOM training
#choose the variable with which to train the SOM
#the following selects column 4,7,23,24 (2,7,22,24)
library(IRkernel)
data_train<-data[,c(2,3,7,8,23,24)]
#now train the SOM using the kohonen method
data_train_matrix<-as.matrix(scale(data_train))
names(data_train_matrix)<-names(data_train)
require(kohonen)
som_grid<-somgrid(xdim=10, ydim=10, topo="hexagonal")
#som_grid
#Train som model
system.time(som_model<-som(data_train_matrix,
              grid=som_grid,
              rlen=1000,
              alpha=c(0.9,0.02),
              #n.hood="circular",
              keep.data=TRUE))
rm(som_grid, data_train_matrix)

#Appendix D: SOM visualization
#visulaise the som model results
#plot of the training process- how the node distances have stabilised
#custom palette as per kohonen package (not compulsory)
source('./coolBlueHotRed.R')
plot(som_model, type="changes")
#counts within nodes
plot(som_model, type="counts", main="Node Counts", palette.name=coolBlueHotRed)
#map quality
plot (som_model, type="quality", main="Node Quality/Distance", palette.name=coolBlueHotRed)
plot (som_model, type="dist.neighbours", main="SOM neighbour distances", palette.name=grey.colors)
plot(som_model, type="codes")

#Plot a variable from the original data set (will be uncapped etc)
#This function produces a menu for multiple heatmaps
source('./plotHeatMap.R')
plotHeatMap(som_model,data,variable=0)