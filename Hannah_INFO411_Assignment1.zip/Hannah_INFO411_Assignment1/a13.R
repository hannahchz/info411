#show the wcss metric for different clustering sites
setwd('/Users/hannahchz/Desktop/INFO411_assignment1')
#can be used as a rough indicator of the ideal number of clusters
som_model$codes
mydata<-som_model$codes[[1]]
#som_model$codes[[1]] #convert to positive values

wss<-(nrow(mydata))-1*sum(apply(mydata,2,var))
for (i in 2:15)
  wss[i]<-sum(kmeans(mydata, centers=i)$withinss)
par(mar=c(5.1,4.1,4.1,2.1)) #plot margins
plot(1:15, wss, type="b", xlab="Number of clusters", ylab="Within groups sum of squares", main="Within clusters sum of squares (WCSS)")

#Form clusters on grid
#use hierarchical clustering to cluster the codebook vectors
som_cluster<-cutree(hclust(dist(som_model$codes[[1]])),4)

pretty_palette<-c("#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b", "#e377c2")
#Show the map with different colours for every cluster     
plot(som_model, type="mapping", bgcol=pretty_palette[som_cluster], main="Clusters")
add.cluster.boundaries(som_model, som_cluster)
#show the same plot with the codes instead of just colours
plot(som_model,type="codes",bgcol=pretty_palette[som_cluster], main="clusters")
add.cluster.boundaries(som_model, som_cluster)

#CLASSIFICATION
#load dataset
fullDataSet<-read.csv("creditworthiness.csv")
#produce the datset from step 1 preprocessing
avg_seq<-seq(12,45, by=3)
data<-data.frame(fullDataSet[,c((1:9),avg_seq)])
min_data<-fullDataSet[,11:45]
min_data<-min_data[, seq(1,34,by=3)]
min_avg<-apply(min_data,1,mean)
data$min_avg_all12months<-min_avg
max_data<-fullDataSet[,10:45]
max_data<-max_data[,seq(10,35,by=3)]
max_avg<-apply(max_data,1,mean)
data$max_avg_all12months<-max_avg

library(RSNNS)                               
#add credit rating to the data matrix
data$credit.rating<-fullDataSet[,46]
fullDataSet<-data
#shuffle vectors of a dataset
fullDataSet<-fullDataSet[sample(1:nrow(fullDataSet), length(1:nrow(fullDataSet))),1:ncol(fullDataSet)]
rm(min_data)
rm(max_data)
#select all entries for which the credit rating is known
knownData<-subset(fullDataSet, fullDataSet[,24]>0)
#select all entries for which the credit rating is unknown
unknownData<-subset(fullDataSet, fullDataSet[,24]==0)
#separate value from targets
trainValues<-knownData[,1:23]
trainTargets<-decodeClassLabels(knownData[,24])  ##WHERE IS decodeClassLabels
unknownsValues<-unknownData[,1:24]

#split dataset into training and test set
trainset<-splitForTrainingAndTest(trainValues, trainTargets, ratio=0.15)
trainset<-normTrainingAndTestSet(trainset)
model<-mlp(trainset$inputsTrain, trainset$targetsTrain, size=4, learnFuncParams=c(0.03), maxit=40, inputsTest=trainset$inputsTest, targetsTest=trainset$targetsTest)
predictTestSet<-predict(model, trainset$inputsTest)
confusionMatrix(trainset$targetsTrain, fitted.values(model))
confusionMatrix(trainset$targetsTest, predictTestSet)
testsetACC<-confusionMatrix(trainset$targetsTest, predictTestSet)
Atest<-(testsetACC[1,1]/sum((testsetACC[1,])))*100
Btest<-(testsetACC[2,2]/sum((testsetACC[2,])))*100
Ctest<-(testsetACC[3,3]/sum((testsetACC[3,])))*100
print(paste("Test set accuracy cr 1:" , Atest, "%"))
print(paste("Test set accuracy cr 2:", Btest, "%"))
print(paste("Test set accuracy cr 3:", Ctest, "%"))
                                               
par(mfrow) #create multipaneled plot
plotIterativeError(model)
plotRegressionError(predictTestSet[,2],trainset$targetsTest[,2])
plotROC(fitted.values(model)[,2], trainset$targetsTrain[,2])
plotROC(predictTestSet[,2],trainset$targetsTest[,2])
#confusion matrix with 402040-method
confusionMatrix(trainset$targetsTrain,encodeClassLabels(fitted.values(model),method="402040",l=0.4,h=0.6))
#show detailed information of the model
summary(model)
model
weightMatrix(model)
extractNetInfo(model)

                                               
                                               
                                               
                                               
                                               
                                               
                                               
                                               
                                               
                                               
                                               
                                               
                                               
                                               
                                               
                                               
                                               
                                               
                                               
                                               
                                               
                                               
                                               
                                               