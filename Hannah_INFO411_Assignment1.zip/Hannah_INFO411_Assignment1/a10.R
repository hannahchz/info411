setwd('/Users/hannahchz/Desktop/INFO411_assignment1')
library(randomForest)
fit_rf = randomForest(credit.rating~., data=data)
# Create an importance based on mean decreasing gini
importance(fit_rf)
varImp(fit_rf)

library(dplyr) 
library(ggplot2)
library(ggpubr)
theme_set(theme_pubclean())

df <- data %>%
  group_by(paid.back.overdrawn.current.account, credit.rating) %>%
  summarise(counts = n()) %>% 
  top_n(n = 5, wt = counts)

#continuous variable on discrete scale
ggplot(df, aes(x = credit.rating, y = counts)) +
  geom_bar(
    aes(color = as.factor(paid.back.overdrawn.current.account), fill = as.factor(paid.back.overdrawn.current.account)),
    stat = "identity", position = position_stack()
  ) +
  scale_color_brewer(palette="Dark2")+scale_fill_brewer(palette="Dark2")







