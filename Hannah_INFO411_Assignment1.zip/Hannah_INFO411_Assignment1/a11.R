#LOAD LIBRARIES
setwd('/Users/hannahchz/Desktop/INFO411_assignment1')
library(kohonen)
library(dummies)
library(ggplot2)
library(sp)
library(maptools)
library(reshape2)
library(rgeos)
pretty_palette<-c("#1f77b4", "#ff7f0e", "#2ca02c", "d627bd", "9467bd", "8c564b", "#e377c2")
data_raw<-read.csv("creditworthiness.csv", header=T)
#create a matrix called data, removing min, max, and credit rating
avg_seq<-seq(12, 45, by=3)
data<-data.frame(data_raw[,c((1:9), avg_seq)])
#take the average of min data 1-12 in respect to each credit rating row element
min_data<-data_raw[,11:45]
min_data<-min_data[,seq(1,34,by=3)]
min_avg<-apply(min_data,1,mean)
data$min_avg_all12months<-min_avg
#take the average of max data 1-12 in respect to each credit rating row element
max_data<-data_raw[,10:45]
max_data<-max_data[,seq(10,35,by=3)]
max_avg<-apply(max_data,1,mean)
data$max_avg_all12months<-max_avg
#add credit rating to the matrix
data$credit.rating<-data_raw[,46]
rm(min_data)
rm(max_data)
#normalize max and min values
#data$min_avg_all_12months<-(data$min_avg_all_12months-min(data$min_avg_all12months))/(max(data$min_avg_all12months)-min(data$min_avg_all12months))
#data$max_avg_all_12months<-(data$max_avg_all_12months-min(data$max_avg_all12months))/(max(data$max_avg_all12months)-min(data$max_avg_all12months))

#reclassifying data for rattle
data_plot<-data_raw
data_plot$gender<-factor(data_raw$gender, labels=c("male", "female"))
data_plot$functionary<-factor(data_raw$functionary,labels=c("no", "yes"))
data_plot$paid.back.overdrawn.current.account<-factor(data_raw$paid.back.overdrawn.current.account, labels=c("no", "yes"))
data_plot$FI3O.credit_score<-factor(data_raw$FI3O.credit.score, labels=c("not.ok", "ok"))
data_plot$self.employed<-factor(data_raw$self.employed, labels=c("no", "yes"))
data_plot$credit_rating<-factor(data_raw$credit.rating, labels=c("NR", "A", "B", "C"))
data_plot$credit.refused.in.past<-factor(data_raw$credit.refused.in.past, labels=c("no","yes"))

str(data)
set.seed(7)
# load the library
library(mlbench)
library(caret)
correlationMatrix<-cor(data)
#print(correlationMatrix)
# find attributes that are highly corrected (ideally >0.75)
highlyCorrelated <- findCorrelation(correlationMatrix, cutoff=0.3)
print(highlyCorrelated) #8,46

